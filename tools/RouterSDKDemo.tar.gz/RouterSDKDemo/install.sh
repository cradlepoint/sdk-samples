#!/bin/bash
echo "INSTALLATION for RouterSDKDemo on:" >> install.log
date >> install.log
