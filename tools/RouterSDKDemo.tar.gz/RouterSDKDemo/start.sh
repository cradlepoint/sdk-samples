#!/bin/bash
cppython RouterSDKDemo.py
