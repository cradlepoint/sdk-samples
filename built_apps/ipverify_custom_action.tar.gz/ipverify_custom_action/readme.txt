Application Name
================
ipverify_custom_action


Application Version
===================
1.0


NCOS Devices Supported
======================
All


External Requirements
=====================
None


Application Purpose
===================
Create a custom action in a function to be called when an IPverify test status changes.
Provided example is for use with IPVerify ICMP ping test over IPSec tunnel - when it fails the app will restart IPsec.

Expected Output
===============
"VPN Monitor Failed - Restarting Tunnel." when test fails

