#!/bin/bash
cppython simple_web_server.py