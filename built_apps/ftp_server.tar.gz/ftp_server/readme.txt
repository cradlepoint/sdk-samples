Application Name
================
ftp_server


Application Version
===================
2.0


NCOS Devices Supported
======================
ALL


External Requirements
=====================
An FTDI compliant USB storage device for FTP files to serve.


Application Purpose
===================
This application will create an FTP Server on port 2121. One will need
to manually open this port in the device firewall to allow external
access.


Expected Output
===============
Files should be served to an FTP Client connecting to this application

