Application Name
================
shell_sample


Application Version
===================
1.0


NCOS Devices Supported
======================
All


External Requirements
=====================
None


Application Purpose
===================
Provides example how to execute commands at OS shell: "ls - al"

Expected Output
===============

09:19:16 AM INFO shell_sample Output:
	drwxr-xr-x    4 cpshell  cpshell        736 May 11 09:19 .
	drwx------    3 cpshell  cpshell        232 May 11 09:19 ..
	drwxr-xr-x    2 cpshell  cpshell        304 May 11 09:19 METADATA
	drwxr-xr-x    2 cpshell  cpshell        248 May 11 09:19 __pycache__
	-rwxr-xr-x    1 cpshell  cpshell      21156 Jan 27 11:51 csclient.py
	-rwxr-xr-x    1 cpshell  cpshell        271 Jan 24 18:26 package.ini
	-rwxr-xr-x    1 cpshell  cpshell       2555 May 11 09:18 readme.txt
	-rwxr-xr-x    1 cpshell  cpshell        731 May 11 09:19 shell_sample.py
	-rwxr-xr-x    1 cpshell  cpshell         36 Jan 24 18:26 start.sh
