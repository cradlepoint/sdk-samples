#!/bin/bash
cppython gps_probe.py