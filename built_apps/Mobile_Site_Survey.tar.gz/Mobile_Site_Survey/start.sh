#!/bin/bash
cppython Mobile_Site_Survey.py &
./miniserve -p 8001 results/
