#!/bin/bash
mkdir -p results
cppython Mobile_Site_Survey.py
