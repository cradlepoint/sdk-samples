#!/bin/bash
cppython mqtt_azure_tls.py