Application Name
================
gpio_any_wan_connected


Application Version
===================
0.1.0


NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
set GPIO out high when any wan (not just modems) is connected