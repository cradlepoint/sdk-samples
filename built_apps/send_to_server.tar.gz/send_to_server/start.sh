#!/bin/bash
cppython send_to_server.py