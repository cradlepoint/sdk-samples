#!/bin/bash
cppython ibr1700_gnss.py