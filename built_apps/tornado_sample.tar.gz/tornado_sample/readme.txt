Application Name
================
tornado_sample


Application Version
===================
1.0


NCOS Devices Supported
======================
ALL


External Requirements
=====================
Forward Primary LAN Zone to Router Zone Default Allow All to access Web UI from LAN.


Application Purpose
===================
Runs webserver on port 9001
Simple framework for starting a tornado webserver with a GET method.

Expected Output
===============
Browse to your router IP address port 9001: "Hello Cradlepoint!"

