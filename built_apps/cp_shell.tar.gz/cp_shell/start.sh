#!/bin/bash
cppython cp_shell.py
