#!/bin/bash
cppython throttle_cellular_datacap.py start