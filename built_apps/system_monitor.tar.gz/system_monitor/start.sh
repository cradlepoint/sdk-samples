#!/bin/bash
cppython system_monitor.py