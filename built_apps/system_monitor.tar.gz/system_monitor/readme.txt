Application Name
================
system_monitor


Application Version
===================
0.1


NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
Get various system diagnostics, alert on thresholds, and put current status in asset_id field
