Application Name
================
geofences


Application Version
===================
0.1.0


NCOS Devices Supported
======================
ALL


External Requirements
=====================
GPS Antenna


Application Purpose
===================
Send alert when entering or exiting configured geofences.