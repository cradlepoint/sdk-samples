#!/bin/bash
cppython serial_vibration_test.py
