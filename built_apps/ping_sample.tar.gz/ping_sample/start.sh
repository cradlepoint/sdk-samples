#!/bin/bash
cppython ping_sample.py