#!/bin/bash
cppython DESC_Interactive.py