Application Name
================
Desc_interactive


Application Version
===================
0.1


NCOS Devices Supported
======================
ALL


External Requirements
=====================


Application Purpose
===================
This application will set the device description to visually show
the up/down status of ethernet ports.


Expected Output
===============
Description updated
Log printed

