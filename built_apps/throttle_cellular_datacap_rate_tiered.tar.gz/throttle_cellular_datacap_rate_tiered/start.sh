#!/bin/bash
cppython throttle_cellular_datacap_rate_tiered.py start