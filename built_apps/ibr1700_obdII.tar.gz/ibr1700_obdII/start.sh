#!/bin/bash
cppython ibr1700_obdII.py
