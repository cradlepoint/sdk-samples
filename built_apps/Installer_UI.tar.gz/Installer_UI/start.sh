#!/bin/bash
cppython Installer_UI.py