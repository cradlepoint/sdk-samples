#!/bin/bash
cppython serial_temp.py
