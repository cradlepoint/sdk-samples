#!/bin/bash
cppython ports_status.py