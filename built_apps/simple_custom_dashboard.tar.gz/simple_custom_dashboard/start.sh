#!/bin/bash
cppython simple_custom_dashboard.py