# Common settings used by app_template

# Used for logging or anytime the app name is needed
APP_NAME = 'cpu_usage'
