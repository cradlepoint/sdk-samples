Application Name
================
cpu_usage

Application Version
===================
1.0


NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
cpu_usage.py gets usage information from the router every 30 seconds and writes it in json to a usb stick.

Made by Harvey Breaux for use with Cradlepoint


Expected Output
===============
Your USB drive should get populated with usage_info.txt that will contain historical usage stats in a json format

